package com.codewithmosh;

import java.text.NumberFormat;
import java.util.Scanner;

public class Main {

    final static byte MONTHS_IN_YEAR = 12;
    final static byte PERCENT = 100;

    public static void main(String[] args) {

        System.out.println("***** Welcome to the Mortgage Calculator *****");

        NumberFormat dollar = NumberFormat.getCurrencyInstance();
        //Set up initial scanner class to take inputs
        Scanner scanner = new Scanner(System.in);

        int principalLoan = (int) readNumber("Principal: ", 1000, 1_000_000);
        String loanAmount = dollar.format(principalLoan);
        System.out.println("Your principal is $" + loanAmount +".");

        //??>>>Needs a min of 1 year to a max of 30 years<<<

        float interestRate = (float) readNumber("Enter your APR/Interest rate: ", 1.0, 30.0);
        System.out.println("Your interest rate is: " + interestRate + "%.");

        byte term = (byte) readNumber("Enter your loan term length: ", 1, 30);
        System.out.println("Your term length is " + term + " years.");
//
        System.out.println();//LINE BREAK
        //*********Calculations*********
        //Method call
        double mortgage= calculateMortgage(principalLoan, interestRate, term);

        //Formatting the output
        System.out.println("Mortgage");
        System.out.println("=================");
        String monthlyPayment = dollar.format(mortgage);
        System.out.println("Your monthly payment is: " + monthlyPayment +" per month.");
        System.out.println("======================================================");

        System.out.println("Payment Schedule\n" +
                "=================================================");
        //Create For loop to show balance after each month of payments
        for (short month = 1; month <= term * MONTHS_IN_YEAR; month++){
            double balance = calculateBalance(principalLoan, interestRate, term, month);
            System.out.println(NumberFormat.getCurrencyInstance().format(balance));
        }


        //>> User will be asked if they want to restart or terminate program <<<
    }

    public static double readNumber(String prompt, double min, double max){
        //??Interest rate needs to have minimum of 0, user will be stuck in prompt until done so??
        Scanner scanner = new Scanner(System.in);
        //declare a generic variable for user input
        double value;
        while(true) {
//        //Prompt for Interest rate
            System.out.print(prompt);
//        //Intake of Interest Rate
            value = scanner.nextFloat();
            if ((value >=min) && (value <=max))
                break;
            System.out.println("Enter a value between" + min + " and " + max);
        }
        return value;

    }

    public static double calculateMortgage(int principalLoan,
                                           float interestRate,
                                           byte term){

        //Calculating how months in the term
        short termMonths = (short) (term * MONTHS_IN_YEAR);
        //Interest calculations
        float monthlyInterest = ((interestRate / PERCENT) / MONTHS_IN_YEAR);
        //Calculating monthly mortgage payment with interest rate
        double monthlyMortgage = (principalLoan * ((monthlyInterest * (Math.pow((1 + monthlyInterest), termMonths)))
                /((Math.pow((1 + monthlyInterest), termMonths)) -1)));
        return monthlyMortgage;
    }

    public static double calculateBalance(int principalLoan,
                                          float interestRate,
                                          byte term,
                                          short numberOfPaymentsMade){

        short termMonths = (short) (term * MONTHS_IN_YEAR);
        float monthlyInterest = ((interestRate / PERCENT) / MONTHS_IN_YEAR);
        float numberOfPayments = termMonths;

        double balance = (principalLoan *
                ((Math.pow((1 + monthlyInterest), numberOfPayments)) - (Math.pow(1 + monthlyInterest,numberOfPaymentsMade))))
                /((Math.pow((1 + monthlyInterest), numberOfPayments)) -1);

        return balance;
    }
}
