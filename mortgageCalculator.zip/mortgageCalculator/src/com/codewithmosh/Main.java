package com.codewithmosh;

import java.text.NumberFormat;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        //Defining Variables
        final byte MONTHS_IN_YEAR = 12;
        final byte PERCENT = 100;

        //Set up initial scanner class to take inputs
        Scanner scanner = new Scanner(System.in);
        //Opening program Welcome screen
        System.out.print("Welcome to the Mortgage Calculator! \n"
                            + "Enter your Principal: ");

        //Intake of principal
//        Scanner principal = new Scanner(System.in);
        int principalLoan = scanner.nextInt();
        NumberFormat dollar = NumberFormat.getCurrencyInstance();
        String loanAmount = dollar.format(principalLoan);

//        System.out.println("Your principal is $" + loanAmount);

//        //Prompt for Interest rate
        System.out.print("Enter your annual interest rate: ");
//        //Intake of Interest Rate
        float interestRate = scanner.nextFloat();

//        System.out.println("Your interest rate is " + interestRate + " %");
//
//        //Prompt for term length
        System.out.print("Enter your loan term length in years: ");
//        //Intake of Term Length
        int term = scanner.nextInt();
//        System.out.println("Your term length is " + term + " years long.");
//
        //Interest calculations
        float monthlyInterest = ((interestRate / PERCENT) / MONTHS_IN_YEAR);
        int termMonths = (term * MONTHS_IN_YEAR);
        double monthPay = Math.pow((1 + monthlyInterest), termMonths);

        double monthlyMortgage = principalLoan * ((monthlyInterest * monthPay)/(monthPay -1));
//        NumberFormat pay = NumberFormat.getCurrencyInstance();
        String monthlyPayment = dollar.format(monthlyMortgage);
        System.out.println("Your monthly payment is: " + monthlyPayment +" per month.");

    }
}
