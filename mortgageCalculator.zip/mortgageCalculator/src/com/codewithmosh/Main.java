package com.codewithmosh;

import java.text.NumberFormat;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        //Defining Variables
        final byte MONTHS_IN_YEAR = 12;
        final byte PERCENT = 100;
        int principalLoan = 0;
        float interestRate = 0;
        float monthlyInterest = 0;
        int term = 0;
        NumberFormat dollar = NumberFormat.getCurrencyInstance();
        //Set up initial scanner class to take inputs
        Scanner scanner = new Scanner(System.in);

        //>>Need to set a minimum and maximum limit of 1,000 to 1,000,000<<
        //>> This needs to be a loop until user follow input prompt<<

        while(true){
//          Opening program Welcome screen
            System.out.print("Welcome to the Mortgage Calculator! \n"
                    + "Enter your Principal (1,000 to 1,000,000): ");
//            NumberFormat dollar = NumberFormat.getCurrencyInstance();
            principalLoan = scanner.nextInt();
            if ((principalLoan >= 1_000) && (principalLoan <= 1_000_000))
                break;
                System.out.println("Enter a number between 1,000 to 1,000,000.");
        }
        String loanAmount = dollar.format(principalLoan);

        System.out.println("Your principal is $" + loanAmount);

        //??Interest rate needs to have minimum of 0, user will be stuck in prompt until done so??
        while(true) {
//        //Prompt for Interest rate
            System.out.print("Enter your annual interest rate: ");
//        //Intake of Interest Rate
            interestRate = scanner.nextFloat();
            if ((interestRate >=1.0) && (interestRate <=30.0)) {
                //Interest calculations
                monthlyInterest = ((interestRate / PERCENT) / MONTHS_IN_YEAR);
                break;
            }
            System.out.println("Enter a value between 1 and 30.");
        }
        System.out.println("Your interest rate is " + interestRate + " %");

        //??>>>Needs a min of 1 year to a max of 30 years<<<
        while(true){
            //Prompt for term length
            System.out.print("Enter your loan term length in years between 1 and 30: ");
//        //Intake of Term Length
            term = scanner.nextInt();
//            if (term <= 1.0 && term >= 30.0){
//                break;
//            }
//            System.out.println("Enter a value between 1 and 30.");

            if((term >= 1.0) && (term <= 30.0)) {
                break;
            }
            System.out.println("Enter a value between 1 and 30.");
        }
        System.out.println("Your term length is " + term + " years long.");
//
        //*********Calculations*********
        //Calculating how months in the term
        int termMonths = (term * MONTHS_IN_YEAR);
        //Calculating monthly mortgage payment with interest rate
        double monthlyMortgage = (principalLoan * ((monthlyInterest * (Math.pow((1 + monthlyInterest), termMonths)))
                                /((Math.pow((1 + monthlyInterest), termMonths)) -1)));
        //Formatting the output
        NumberFormat pay = NumberFormat.getCurrencyInstance();
        String monthlyPayment = dollar.format(monthlyMortgage);
        System.out.println("Your monthly payment is: " + monthlyPayment +" per month.");


        //>> User will be asked if they want to restart or terminate program <<<
    }
}
